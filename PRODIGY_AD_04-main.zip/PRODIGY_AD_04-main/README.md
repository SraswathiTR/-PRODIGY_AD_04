Tic-tac-toe is a two-player game where the goal is to form a line of three of your marks (X or O) horizontally, vertically, or diagonally on a 3x3 grid. Players take turns placing their marks in empty cells. The game ends when one player achieves a winning line or when the grid is full, resulting in a draw. Players cannot overwrite each other's marks, and the first to complete a line wins.

Download APK : https://drive.google.com/file/d/1oosBSZttBIgKbcFp21Qh7tKLiAK0QNFJ/view?usp=sharing
