package com.example.tic_tak_toe

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
